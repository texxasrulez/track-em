// Placeholder widget to avoid MIME-type errors when the file is missing.
// If/when this plugin exposes a dashboard widget, replace this file with real code.
