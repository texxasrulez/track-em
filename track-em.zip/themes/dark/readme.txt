Dark theme placeholder.
