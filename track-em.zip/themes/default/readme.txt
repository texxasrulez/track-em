Default theme placeholder.
